package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Shopping_Cart {

	WebDriver dr;
	WebDriverWait wait;

	public Shopping_Cart(WebDriver dr) {
		super();
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[1]")
	WebElement pTitle;
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[1]")
	WebElement pTitle1;
	public String productTitle(int i)
	{
		wait = new WebDriverWait(dr,10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[1]")));
		
		String str = null;
		if(i==0)
			str = pTitle.getText();
		else 
			str = pTitle1.getText();
				
		return str;
	}
	
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]")
	WebElement pTotal;
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[4]")
	WebElement pTotal1;
	public String productTotal(int i)
	{
		wait = new WebDriverWait(dr,10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]")));
		String str = null;
		if(i ==0)
			str = pTotal.getText().substring(1);
		else 
			str = pTotal1.getText().substring(1);
		
		return str;
	}
	
	
}
