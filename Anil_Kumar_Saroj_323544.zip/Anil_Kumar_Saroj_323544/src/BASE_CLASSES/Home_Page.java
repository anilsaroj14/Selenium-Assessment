package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Home_Page {
	
	WebDriver dr;
	WebDriverWait wait;

	public Home_Page(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}

	public String returnTitle()
	{
		return dr.getTitle();
	}
	
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td[1]/form/table[1]/tbody/tr/th")
	WebElement text;
	public String returnText()
	{
		wait = new WebDriverWait(dr,10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[1]/tbody/tr/th")));
		
		return text.getText();
	}
	
	@FindBy(name = "category_id")
	WebElement category;
	public void selCat(String str)
	{
		
		Select sel = new Select(category);
		sel.selectByVisibleText(str);
		
	}
	
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[2]/td/input")
	WebElement sData;
	public void  enterData(String str)
	{
		sData.sendKeys(str);
	}
	
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")
	WebElement clk;
	public void searchProduct()
	{
		clk.click();
	}
}
