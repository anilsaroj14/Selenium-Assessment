package BASE_CLASSES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Product_Detail_Page {

	WebDriver dr;

	public Product_Detail_Page(WebDriver dr) {
		super();
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	public String returnTitle()
	{
		return dr.getTitle();
	}
	
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")
	WebElement cQty;
	public void clearQty()
	{
		cQty.clear();
	}
	
	public void enterQty(String str)
	{
		cQty.sendKeys(str);
	}
	
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")
	WebElement atc;
	public void addToCart()
	{
		atc.click();
	}
	
	
}
