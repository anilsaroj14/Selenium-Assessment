package BASE_CLASSES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Search_Results_Page {
	
	WebDriver dr;

	public Search_Results_Page(WebDriver dr) {
		super();
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	public String returnTitle()
	{
		return dr.getTitle();
	}
	
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")
	WebElement clkP;
	public void clickProduct()
	{
		clkP.click();
	}
	
	
	

}
