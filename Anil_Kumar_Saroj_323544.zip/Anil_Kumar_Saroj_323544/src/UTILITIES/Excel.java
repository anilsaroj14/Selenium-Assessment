package UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	
	public String[][] readExcel()
	{
		String [][] str1 = new String[2][3];
		
		
		try {
			
			File f = new File("sel.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			
			
			for(int i=0;i<2;i++)
			{
				XSSFRow r = sh.getRow(i+1);
				XSSFCell c = r.getCell(0);
				str1[i][0] = c.getStringCellValue();
				
				str1[i][1] = r.getCell(1).getStringCellValue();

				str1[i][2] = Double.toString(r.getCell(2).getNumericCellValue());
			}
	
		
			
			
		}
		 catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return str1;
	}
	
	

}
