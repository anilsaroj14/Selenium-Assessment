package TESTNG_TESTS;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.Home_Page;
import BASE_CLASSES.Product_Detail_Page;
import BASE_CLASSES.Search_Results_Page;
import UTILITIES.Excel;
import UTILITIES.Excel1;

public class TestNG1 {
	
	WebDriver dr;
	Home_Page hp;
	SoftAssert sa;
	String[][] cat;
	Logger log;
	Search_Results_Page srp;
	Product_Detail_Page pdp;
	String[][] cart;
	
	@BeforeTest
	public void bc()
	{
		Excel ex = new Excel();
		cat = ex.readExcel();
		
		Excel1 ex1 = new Excel1();
		cart = ex1.readExcel();
		
	}
	
  @Test(priority = 1)
  public void launchBrowser() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
	  dr = new ChromeDriver();
	  dr.get("http://examples.codecharge.com/Store/Default.php");
	  
  }
  int i =0;
  @Test(priority = 2, dataProvider ="CatData" )
  public void Home_Page_Test(String category, String search, String qty)
  {
	  hp = new Home_Page(dr);
	  verifyTitle();
	  verifySearchText();
	  selectCat(category);
	  enterSearchData(search);
	  clickSearch();
	  
	  srp = new Search_Results_Page(dr);
	  verifyTitle1();
	  clickProd();
	  
	  pdp = new Product_Detail_Page(dr);
	  verifyTitle2();
	  clearQ();
	  enterQ(qty);
	  addCart();
	  if(i == 0)
		  dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[1]")).click();
	  i++;

  }
  
  @DataProvider(name = "CatData")
  public String[][] catData()
  {
	  return cat;
  }
  
  public void verifyTitle()
  {
	  String str = hp.returnTitle();
	  sa = new SoftAssert();
	  sa.assertEquals(str, "Online Bookstore");
	  
	  log = Logger.getLogger("devpinoyLogger");
	  log.info("\n==========================================================================\n"
			  	+ "-------------------------------Home_Page--------------------------------\n"
			  	+ "============================================================================\n");
	  log.info("Expected Value : Online Bookstore --  Actual Value : "+str+"  --  Test Result : Passed ");
	  sa.assertAll();
  }
  
  
  
  public void verifySearchText()
  {
	  String str = hp.returnText();
	  sa = new SoftAssert();
	  sa.assertEquals(str, "Search Products");
	  
	  log = Logger.getLogger("devpinoyLogger");
	  log.info("Expected Value : Search Products --  Actual Value : "+str+"  --  Test Result : Passed ");
	  sa.assertAll();
  }
  
  public void selectCat(String category)
  {
	  hp.selCat(category);
	  
//	  log = Logger.getLogger("devpinoyLogger");
//	  log.info("Expected Value : Search Products --  Actual Value : "+str+"  --  Test Result : Passed ");
	  
  }
  
  public void enterSearchData(String search)
  {
	 hp.enterData(search);
	  
  }
  
  public void clickSearch()
  {
	 hp.searchProduct();	  
  }
  
  public void verifyTitle1()
  {
	  String str = srp.returnTitle();
	
	  sa = new SoftAssert();
	  sa.assertEquals(str, "SearchResults");
	  
	  log = Logger.getLogger("devpinoyLogger");
	  log.info("\n==========================================================================\n"
			  	+ "-------------------------------Search_Result_Page--------------------------------\n"
			  	+ "============================================================================\n");
	  log.info("Expected Value : SearchResults --  Actual Value : "+str+"  --  Test Result : Passed ");
	  sa.assertAll();
  }
  
  
  public void clickProd()
  {
	 srp.clickProduct();	  
  }
  
  public void verifyTitle2()
  {
	  String str = pdp.returnTitle();
	  sa = new SoftAssert();
	  sa.assertEquals(str, "ProductDetail");
	  
	  log = Logger.getLogger("devpinoyLogger");
	  log.info("\n==========================================================================\n"
			  	+ "-------------------------------Product_Detail_Page--------------------------------\n"
			  	+ "============================================================================\n");
	  log.info("Expected Value : ProductDetail --  Actual Value : "+str+"  --  Test Result : Passed ");
	  sa.assertAll();
  }
  
  public void clearQ()
  {
	  pdp.clearQty();
  }
  
  public void enterQ(String str)
  {
	  pdp.enterQty(str);
  }
  
  public void addCart()
  {
	  pdp.addToCart();
  }
  
}
