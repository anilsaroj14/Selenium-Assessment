package TESTNG_TESTS;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.Home_Page;
import BASE_CLASSES.Product_Detail_Page;
import BASE_CLASSES.Shopping_Cart;
import UTILITIES.Excel;
import UTILITIES.Excel1;

public class TestNG2 extends TestNG1{
	

	SoftAssert sa;
	Shopping_Cart sc;
		
	int j = 0;
	 @Test(priority = 4, dataProvider ="CartData1" )
	  public void Shopping_Cart_Product(String product)
	  {
		 sc = new Shopping_Cart(dr);
		 prTitle(product,j);
		 j++;
		 
	  
	  }
	 
	 int k = 0;
	 @Test(priority = 5, dataProvider ="CartData2" )
	  public void Shopping_Cart_Total(String total)
	  {
		 sc = new Shopping_Cart(dr);
		 prTotal(total,k);
		 k++;
	  
	  }
	  
	  @DataProvider(name = "CartData1")
	  public String[] cartData1()
	  {
		  String[]cart1 = new String[2];
			cart1[0] = cart[0][0];
			cart1[1] = cart[1][0];
			return cart1;
			
	  }
	  
	  @DataProvider(name = "CartData2")
	  public String[] cartData2()
	  {
		  String[]cart2 = new String[2];
		cart2[0] = cart[0][1];
		cart2[1] = cart[1][1];
		return cart2;
	  }
	  
	  public void prTitle(String product, int n)
	  {
		  String str = sc.productTitle(n);
		  sa = new SoftAssert();
		  sa.assertEquals(str, product);
		  
		  log = Logger.getLogger("devpinoyLogger");
		  log.info("\n==========================================================================\n"
				  	+ "-------------------------------Shopping_Cart--------------------------------\n"
				  	+ "============================================================================\n");
		  log.info("Expected Value : "+product+" --  Actual Value : "+str+"  --  Test Result : Passed ");
		  sa.assertAll();
	  }
	  
	  public void prTotal(String total, int n)
	  {
		  String str = sc.productTotal(n);
		  sa = new SoftAssert();
		  sa.assertEquals(str, total);
		  
		  log = Logger.getLogger("devpinoyLogger");
		  log.info("Expected Value : "+total+" --  Actual Value : "+str+"  --  Test Result : Passed ");
		  sa.assertAll();
	  }
	  
	  
  
}
